# 🚀 Portfolio Merphy Mademba — React + Tailwind CSS (avec Image)

> Version moderne avec image de profil

[![React](https://img.shields.io/badge/React-18.2-61DAFB?logo=react)](https://react.dev)
[![Tailwind](https://img.shields.io/badge/Tailwind-3.4-38B2AC?logo=tailwind-css)](https://tailwindcss.com)
[![Deploy](https://img.shields.io/badge/Deploy-GitHub%20Pages-222?logo=github)](https://fullstackflow-dev.github.io/Portfolio-react-tailwind-white-image-2/)

## 📋 À propos

Portfolio React + Tailwind CSS avec image de profil circulaire dans le Hero.

**🔗 Demo :** [fullstackflow-dev.github.io/Portfolio-react-tailwind-white-image-2](https://fullstackflow-dev.github.io/Portfolio-react-tailwind-white-image-2/)

## 🚀 Installation rapide

```bash
npm install
npm run dev
```

Voir le [README complet](#documentation-complète) pour plus de détails.

