import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

/**
 * CONFIGURATION VITE POUR REACT
 * 
 * Vite est un outil de build moderne et ultra-rapide pour les applications web.
 * Il offre :
 * - Hot Module Replacement (HMR) instantané en développement
 * - Build optimisé pour la production avec code splitting automatique
 * - Support natif de TypeScript, JSX, CSS modules
 * 
 * Documentation : https://vitejs.dev/config/
 */
export default defineConfig({
  /**
   * PLUGINS
   * 
   * @vitejs/plugin-react : Active le support complet de React
   * - Transformation JSX/TSX en JavaScript
   * - Fast Refresh (rechargement instantané des composants)
   * - Support des React DevTools
   */
  plugins: [react()],

  /**
   * BASE PATH pour déploiement GitHub Pages
   * 
   * IMPORTANT : Change cette valeur selon ton repo GitHub
   * 
   * Format : '/nom-du-repo/'
   * 
   * Exemples :
   * - Pour https://user.github.io/mon-portfolio/ → base: '/mon-portfolio/'
   * - Pour https://user.github.io/ (repo user.github.io) → base: '/'
   * 
   * Si tu déploies sur Vercel/Netlify, laisse commenté (utilise '/' par défaut)
   */
  base: '/Portfolio-react-tailwind-white-image-2/',

  /**
   * SERVER (développement local)
   */
  server: {
    port: 3000,                     // Port du serveur de dev (défaut: 5173)
    open: true,                     // Ouvre le navigateur automatiquement
  },
})
